# FoodBridge - Student Project Prototype

FoodBridge is a front-end demonstration that connects event organisers listing surplus food with nearby sample NGO partners.

## Technology
- C: nearest-NGO distance and matching logic in `matching.c`
- WebAssembly: `matching.wasm` is compiled from the C source and called by the browser
- HTML/CSS/JavaScript: user interface and form handling

## Run locally
Because browsers fetch WebAssembly as a separate file, run a local web server from this folder:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Publish a public website link
1. Create a GitHub account and a new public repository named `foodbridge`.
2. Upload all five project files: `index.html`, `style.css`, `app.js`, `matching.c`, `matching.wasm`, plus this README.
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. GitHub Pages will publish a URL similar to `https://YOUR-USERNAME.github.io/foodbridge/`.

## Important prototype limitations
- The NGO names and coordinates are fictional sample data for a classroom demonstration, not real organisations or verified collection partners.
- The distance function is a short-distance approximation using latitude/longitude, not road distance or live traffic routing.
- Donation records are saved only in the current browser using localStorage. They are not shared between users or devices.
- The demo does not notify NGOs, book transport, verify food safety, or arrange a real pickup.
- Before any real donation, an authorised recipient must verify food source, handling, storage, packaging, timing and suitability. Never donate food that has already been served to guests or has an uncertain handling history.

## C program summary
`distance_km()` estimates the straight-line distance between two coordinate pairs. `set_ngo()` stores sample NGO coordinates. `find_nearest_ngo()` compares the event location against each NGO and returns the index with the shortest estimated distance. The browser calls these C functions through WebAssembly.
