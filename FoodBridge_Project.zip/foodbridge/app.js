const NGOs = [
  { name: 'Helping Hands Community Kitchen', area: 'Worli', lat: 19.0118, lon: 72.8181, need: 'Prepared vegetarian meals', symbol: '♡' },
  { name: 'Udaan Care Collective', area: 'Lower Parel', lat: 18.9977, lon: 72.8302, need: 'Fresh meal portions', symbol: '✳' },
  { name: 'Sahyog Food Support', area: 'Dadar', lat: 19.0178, lon: 72.8478, need: 'Packaged food donations', symbol: '⌂' },
  { name: 'Asha Community Centre', area: 'Mumbai Central', lat: 18.9696, lon: 72.8194, need: 'Vegetarian and mixed meals', symbol: '❋' }
];

const partnerGrid = document.getElementById('partnerGrid');
partnerGrid.innerHTML = NGOs.map(n => `<article class="partner-card"><span class="demo-label">Sample partner · fictional</span><div class="partner-symbol">${n.symbol}</div><h3>${n.name}</h3><p>${n.area}, Mumbai</p><div class="partner-meta"><span>${n.need}</span><span>Demo</span></div></article>`).join('');

let cCore;
async function loadCCore() {
  const response = await fetch('./matching.wasm');
  if (!response.ok) throw new Error('Could not load the C matching module.');
  const bytes = await response.arrayBuffer();
  const result = await WebAssembly.instantiate(bytes, {});
  cCore = result.instance.exports;
  NGOs.forEach((ngo, index) => cCore.set_ngo(index, ngo.lat, ngo.lon));
}

const form = document.getElementById('donationForm');
const resultBox = document.getElementById('result');
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  resultBox.hidden = false;
  resultBox.textContent = 'Finding the nearest sample NGO using the C matching program…';
  try {
    if (!cCore) await loadCCore();
    const data = new FormData(form);
    const lat = Number(data.get('lat'));
    const lon = Number(data.get('lon'));
    const nearestIndex = cCore.find_nearest_ngo(lat, lon, NGOs.length);
    if (nearestIndex < 0 || !Number.isFinite(lat) || !Number.isFinite(lon)) throw new Error('Please enter valid location coordinates.');
    const ngo = NGOs[nearestIndex];
    const distance = cCore.get_nearest_distance();
    const donation = {
      event: data.get('event'), type: data.get('type'), area: data.get('area'),
      food: data.get('food'), quantity: Number(data.get('quantity')),
      category: data.get('category'), deadline: data.get('deadline'),
      contact: data.get('contact'), matchedNgo: ngo.name,
      distanceKm: Number(distance.toFixed(2)), status: 'Awaiting NGO confirmation',
      createdAt: new Date().toISOString()
    };
    const saved = JSON.parse(localStorage.getItem('foodbridge-donations') || '[]');
    saved.unshift(donation);
    localStorage.setItem('foodbridge-donations', JSON.stringify(saved.slice(0, 20)));
    resultBox.innerHTML = `<strong>Nearest sample NGO found: ${ngo.name}</strong><br>${ngo.area}, Mumbai · Approximately ${distance.toFixed(2)} km away<br><span class="result-sub">${donation.quantity} portions of ${donation.food}. Status: ${donation.status}. This is a demo match only; contact and acceptance are not real.</span>`;
  } catch (error) {
    resultBox.textContent = error.message + ' Please try again.';
  }
});
