/* FoodBridge - C core: nearest suitable NGO matching.
   This module is compiled to WebAssembly and called by the website. */
#define MAX_NGOS 32

static double ngo_lat[MAX_NGOS];
static double ngo_lon[MAX_NGOS];
static double last_distance = 0.0;

/* Newton iteration square root; avoids a dependency on the C math library. */
static double sqrt_approx(double x) {
    if (x <= 0.0) return 0.0;
    double guess = x > 1.0 ? x : 1.0;
    for (int i = 0; i < 24; ++i) guess = 0.5 * (guess + x / guess);
    return guess;
}

/* Approximate distance in km for short distances, suitable for a demo matcher.
   Latitude: about 111 km/degree. Longitude is adjusted for latitude. */
__attribute__((visibility("default")))
double distance_km(double lat1, double lon1, double lat2, double lon2) {
    const double km_per_degree_lat = 111.0;
    double mean_lat = (lat1 + lat2) * 0.5;
    /* cos(latitude) approximation is adequate for this classroom prototype. */
    double radians = mean_lat * 0.017453292519943295;
    double x = (lon2 - lon1) * 111.0 * (1.0 - (radians * radians) * 0.5);
    double y = (lat2 - lat1) * km_per_degree_lat;
    return sqrt_approx(x*x + y*y);
}

__attribute__((visibility("default")))
void set_ngo(int index, double lat, double lon) {
    if (index >= 0 && index < MAX_NGOS) {
        ngo_lat[index] = lat;
        ngo_lon[index] = lon;
    }
}

/* Returns index of nearest NGO, or -1 if count is invalid. */
__attribute__((visibility("default")))
int find_nearest_ngo(double event_lat, double event_lon, int count) {
    if (count < 1 || count > MAX_NGOS) return -1;
    int nearest = 0;
    double best = distance_km(event_lat, event_lon, ngo_lat[0], ngo_lon[0]);
    for (int i = 1; i < count; ++i) {
        double current = distance_km(event_lat, event_lon, ngo_lat[i], ngo_lon[i]);
        if (current < best) { best = current; nearest = i; }
    }
    last_distance = best;
    return nearest;
}

__attribute__((visibility("default")))
double get_nearest_distance(void) { return last_distance; }
