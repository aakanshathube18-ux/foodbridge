/* Optional terminal demo: compile with gcc matching_demo.c -o matching_demo */
#include <stdio.h>
#include "matching.c"

int main(void) {
    /* Fictional sample NGO coordinates for a classroom demonstration. */
    set_ngo(0, 19.0118, 72.8181);
    set_ngo(1, 18.9977, 72.8302);
    set_ngo(2, 19.0178, 72.8478);
    set_ngo(3, 18.9696, 72.8194);

    double event_lat = 19.0176;
    double event_lon = 72.8562;
    int nearest = find_nearest_ngo(event_lat, event_lon, 4);

    printf("FoodBridge C Matching Demo\n");
    printf("Event coordinates: %.4f, %.4f\n", event_lat, event_lon);
    printf("Nearest sample NGO index: %d\n", nearest);
    printf("Approximate straight-line distance: %.2f km\n", get_nearest_distance());
    return 0;
}
